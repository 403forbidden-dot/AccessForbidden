import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Cpu, 
  Settings, 
  Download, 
  Zap, 
  Terminal as TerminalIcon, 
  Code, 
  RefreshCw,
  Box,
  Layers,
  Activity,
  AlertTriangle,
  AlertCircle
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import JSZip from 'jszip';
import { ESRGAN_PYTHON_CODE } from './lib/pythonSnippets';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Terminal = ({ logs }: { logs: string[] }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="bg-[#0A0E17] h-48 w-full p-4 font-mono text-[11px] overflow-y-auto border border-gray-800 rounded-2xl" ref={scrollRef}>
      {logs.map((log, i) => (
        <div key={i} className="mb-1 flex">
          <span className="text-cyan-500 mr-2 opacity-70">process@Forbidden:~$</span>
          <span className="text-gray-400">{log}</span>
        </div>
      ))}
    </div>
  );
};

const Header = () => (
  <header className="h-16 border-b border-gray-800 flex items-center justify-between px-6 bg-[#0E1421] shrink-0 sticky top-0 z-50">
    <div className="flex items-center space-x-3">
      {/* Professional Logo Icon */}
      <div className="relative w-10 h-10 group cursor-pointer">
        <div className="absolute inset-0 bg-cyan-500 rounded-xl rotate-45 opacity-20 group-hover:rotate-90 transition-transform duration-500" />
        <div className="absolute inset-0 bg-blue-600 rounded-xl -rotate-12 opacity-20 group-hover:rotate-0 transition-transform duration-500" />
        <div className="relative w-full h-full bg-gradient-to-tr from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20 overflow-hidden">
          <Zap className="w-5 h-5 text-white animate-pulse" />
          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>
      <div className="flex flex-col leading-none">
        <span className="text-xl font-bold tracking-tighter text-white uppercase italic">Access<span className="text-cyan-400">Forbidden</span></span>
        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-[0.4em] mt-0.5">Neural Systems</span>
      </div>
    </div>
    <div className="flex items-center space-x-6">
      <div className="flex items-center bg-gray-900 rounded-full px-4 py-1.5 border border-gray-800">
        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse mr-2"></div>
        <span className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">Engine: ULTRA_STABLE v4.8</span>
      </div>
      <div className="hidden md:flex items-center gap-4 text-xs font-mono text-gray-500">
        <div className="flex items-center gap-1">
          <div className="w-1 h-1 rounded-full bg-cyan-500" />
          <span className="uppercase">Unrestricted</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-1 h-1 rounded-full bg-cyan-500" />
          <span className="uppercase">Infinite Batch</span>
        </div>
      </div>
    </div>
  </header>
);

const MetricCard = ({ label, value, icon: Icon, progress, subtext }: any) => (
  <div className="bg-gray-900/60 rounded-2xl p-4 border border-gray-800 relative overflow-hidden group hover:border-gray-700 transition-colors">
    <div className="flex justify-between items-start mb-2">
      <span className="text-[10px] font-bold uppercase tracking-[0.1em] text-gray-500">{label}</span>
      <Icon className="w-4 h-4 text-cyan-400 opacity-60" />
    </div>
    <div className="text-2xl font-bold tracking-tight mb-1">{value}</div>
    {progress !== undefined ? (
      <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden mt-3">
        <div 
          className="h-full bg-cyan-500 shadow-[0_0_8px_rgba(34,211,238,0.5)] transition-all duration-1000" 
          style={{ width: typeof progress === 'string' ? progress : `${progress}%` }}
        />
      </div>
    ) : (
      <div className="text-[10px] text-gray-500 uppercase font-medium">{subtext}</div>
    )}
  </div>
);

// --- Main App ---

export default function App() {
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [processing, setProcessing] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);
  const [processedCount, setProcessedCount] = useState(0);
  const [logs, setLogs] = useState<string[]>(["SYSTEM BOOT COMPLETE", "KERNEL: HighSpeedParallel v4.0 Active", "Waiting for Unlimited Batch..."]);
  const [upscaleFactor, setUpscaleFactor] = useState(2);
  const [outputFormat, setOutputFormat] = useState("png");
  const [quality, setQuality] = useState(90);
  const [memoryUsage, setMemoryUsage] = useState("0%");
  const [showCode, setShowCode] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      const base = processing ? 82 : 21;
      const jitter = Math.random() * 5;
      setMemoryUsage(`${(base + jitter).toFixed(1)}%`);
    }, 1500);
    return () => clearInterval(interval);
  }, [processing]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev.slice(-20), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const handleFilesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []) as File[];
    if (selected.length > 0) {
      setFiles(prev => [...prev, ...selected]);
      const newPreviews = selected.slice(0, 8).map(f => URL.createObjectURL(f));
      setPreviews(prev => [...prev, ...newPreviews].slice(0, 16));
      addLog(`SYSTEM DETECTED ${selected.length} FILES. INTEGRATING INTO BUFFER.`);
    }
  };

  const clearBatch = () => {
    setFiles([]);
    setPreviews([]);
    addLog("BATCH BUFFER FLUSHED.");
  };

  const processBatch = async () => {
    if (files.length === 0) return;
    
    setProcessing(true);
    setBatchProgress(0);
    setProcessedCount(0);
    addLog(`INITIALIZING BATCH: ${files.length} ITEMS`);
    addLog(`PROTOCOL: Matrix High-Speed Flow`);

    const zip = new JSZip();
    let completed = 0;

    try {
      // Semi-Parallel approach (Process in small clusters of 2 for speed + safety)
      const CONCURRENCY = 2;
      for (let i = 0; i < files.length; i += CONCURRENCY) {
        const chunk = files.slice(i, i + CONCURRENCY);
        
        await Promise.all(chunk.map(async (file, chunkIdx) => {
          const globalIdx = i + chunkIdx;
          addLog(`PROCESSING [${globalIdx + 1}/${files.length}]: ${file.name}`);
          
          const formData = new FormData();
          formData.append("image", file);
          formData.append("factor", upscaleFactor.toString());
          formData.append("format", outputFormat);
          formData.append("quality", quality.toString());

          try {
            const response = await fetch("/api/upscale", {
              method: "POST",
              body: formData,
            });

            if (response.ok) {
              const blob = await response.blob();
              const safeName = file.name.replace(/[^a-z0-9.]/gi, '_').split('.')[0];
              zip.file(`${safeName}_upscaled.${outputFormat}`, blob);
            } else {
              const errText = await response.text();
              addLog(`ERR [${file.name}]: ${errText}`);
            }
          } catch (err) {
            addLog(`FAIL [${file.name}]: Network Error`);
          } finally {
            completed++;
            setProcessedCount(completed);
            setBatchProgress(Math.round((completed / files.length) * 100));
          }
        }));
      }

      addLog("ARCHIVING: BUILDING NEURAL PACKAGE...");
      const zipBlob = await zip.generateAsync({ type: "blob" });
      
      const downloadUrl = window.URL.createObjectURL(zipBlob);
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = downloadUrl;
      link.download = `AccessForbidden.zip`;
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        window.URL.revokeObjectURL(downloadUrl);
        document.body.removeChild(link);
      }, 500);

      addLog(`SUCCESS: ${files.length} ITEMS DELIVERED.`);
    } catch (error: any) {
      addLog(`CRITICAL SYSTEM ERROR: ${error.message}`);
      console.error(error);
    } finally {
      setProcessing(false);
      setBatchProgress(0);
      setProcessedCount(0);
    }
  };

  const handleSingleUpscale = async (idx: number) => {
    const file = files[idx];
    if (!file) return;
    setProcessing(true);
    addLog(`INIT SINGLE UPSCALE: ${file.name}`);
    
    const formData = new FormData();
    formData.append("image", file);
    formData.append("factor", upscaleFactor.toString());
    formData.append("format", outputFormat);
    formData.append("quality", quality.toString());

    try {
      const response = await fetch("/api/upscale", { method: "POST", body: formData });
      if (!response.ok) {
        let errorMsg = "Unknown Engine Failure";
        try {
          const errorText = await response.text();
          errorMsg = errorText || response.statusText || `HTTP ${response.status}`;
        } catch (e) {
          errorMsg = `Status: ${response.status}`;
        }
        throw new Error(`DETECTION: ${errorMsg}`);
      }
      
      const blob = await response.blob();
      if (blob.size === 0) throw new Error("Empty Payload Received");

      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = downloadUrl;
      link.download = `upscaled_${file.name.split('.')[0]}.${outputFormat}`;
      document.body.appendChild(link);
      link.click();
      
      setTimeout(() => {
        window.URL.revokeObjectURL(downloadUrl);
        document.body.removeChild(link);
      }, 500);

      addLog(`SINGLE SUCCESS: ${file.name} DELIVERED.`);
    } catch (error: any) {
      const isNetworkError = error.message === 'Failed to fetch' || error.name === 'TypeError';
      const msg = isNetworkError 
        ? "Network Error: Engine unresponsive (Likely RAM/Timeout)" 
        : error.message;
      addLog(`ERROR: ${msg}`);
      console.error(error);
    } finally {
      setProcessing(false);
    }
  };

  const formats = ["png", "jpg", "jpeg", "webp", "tiff", "avif", "heif", "gif", "bmp", "pdf"];

  return (
    <div className="min-h-screen flex flex-col font-sans bg-[#0B0F19] text-gray-100 selection:bg-cyan-500/30">
      <Header />

      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        
        {/* Left Sidebar: Controls */}
        <aside className="lg:col-span-3 border-r border-gray-800 bg-[#0E1421] p-6 flex flex-col gap-8 shrink-0 overflow-y-auto">
          
          <div className="space-y-4">
             <div className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.2em] px-1 italic">Processing Matrix</div>
             <div className="flex items-center space-x-3 px-4 py-3 bg-cyan-600/10 text-cyan-400 rounded-xl border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.05)]">
                <Layers className="w-5 h-5 animate-pulse" />
                <span className="font-bold text-sm tracking-tight">Massive Batch Engine</span>
             </div>
             <div 
              onClick={clearBatch}
              className="flex items-center space-x-3 px-4 py-3 text-gray-500 hover:text-rose-500 hover:bg-rose-500/5 rounded-xl transition-all cursor-pointer group border border-transparent hover:border-rose-500/20"
             >
                <RefreshCw className="w-5 h-5 group-hover:rotate-180 transition-transform duration-500" />
                <span className="font-medium text-sm">Clear Active Buffer</span>
             </div>
          </div>

          <div className="h-px bg-gray-800/50" />

          <section className="flex flex-col gap-6">
            <h2 className="text-[10px] font-bold uppercase text-gray-500 tracking-widest flex items-center gap-2">
              <Settings className="w-3 h-3" /> Core Config (Unlimited)
            </h2>

            <div className="space-y-3">
              <label className="text-[10px] text-gray-500 font-bold uppercase tracking-widest block">Neural Scaling</label>
              <div className="grid grid-cols-3 gap-2">
                {[2, 3, 4].map(factor => (
                  <button 
                    key={factor}
                    onClick={() => setUpscaleFactor(factor)}
                    className={cn(
                      "py-2.5 text-[10px] font-bold rounded-lg border transition-all",
                      upscaleFactor === factor 
                        ? "bg-cyan-600 border-cyan-400 text-white shadow-lg shadow-cyan-500/20" 
                        : "bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700"
                    )}
                  >
                    {factor}x
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] text-gray-500 font-bold uppercase tracking-widest block">Output Formats (Universal)</label>
              <div className="grid grid-cols-3 gap-2">
                {formats.map(fmt => (
                  <button 
                    key={fmt}
                    onClick={() => setOutputFormat(fmt)}
                    className={cn(
                      "py-2.5 text-[10px] font-black rounded-lg border uppercase transition-all",
                      outputFormat === fmt 
                        ? "bg-white border-white text-black" 
                        : "bg-gray-900 border-gray-800 text-gray-600 hover:bg-gray-800"
                    )}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <button 
                onClick={processBatch}
                disabled={files.length === 0 || processing}
                className={cn(
                  "w-full py-4 rounded-2xl font-bold text-[10px] uppercase tracking-[0.2em] transition-all active:scale-95 group relative overflow-hidden",
                  files.length > 0 && !processing 
                    ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-xl shadow-cyan-500/40 hover:brightness-110" 
                    : "bg-gray-800 text-gray-600 cursor-not-allowed border border-gray-700"
                )}
              >
                <div className="relative z-10 flex items-center justify-center gap-3">
                  {processing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin text-cyan-200" />
                      <span>{batchProgress > 0 ? `PROCESSING: ${batchProgress}%` : 'INITIALIZING...'}</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 fill-cyan-400 text-cyan-400" />
                      <span>Execute Upscale Batch</span>
                    </>
                  )}
                </div>
                {processing && <motion.div layoutId="progress" className="absolute inset-0 bg-white/10" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ duration: 60, ease: "linear" }} />}
              </button>
              
              <div className="text-center">
                 <p className="text-[9px] text-cyan-700 font-bold uppercase tracking-widest italic mb-2">
                   Unrestricted Matrix Mode: Active
                 </p>
                 {processing && (
                   <div className="text-[10px] text-cyan-500/80 font-bold tracking-tighter">
                     UPSCALED: <span className="text-white">{processedCount}</span> OF <span className="text-white">{files.length}</span> IMAGES
                   </div>
                 )}
              </div>
            </div>
          </section>

          <div className="mt-auto pt-6 border-t border-gray-800 space-y-4">
             <div className="bg-gradient-to-br from-indigo-900/20 to-transparent border border-indigo-500/10 rounded-2xl p-5 relative overflow-hidden">
                <div className="relative z-10">
                  <h4 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                    <Zap className="w-3 h-3" /> Ultra-Speed Lock
                  </h4>
                  <p className="text-[10px] text-gray-500 mt-2 leading-relaxed">System locked at 3.0s per upload for maximum throughput.</p>
                </div>
                <div className="absolute -right-4 -bottom-4 w-16 h-16 bg-indigo-500/10 rounded-full blur-2xl"></div>
             </div>

             <button 
                onClick={() => setShowCode(!showCode)}
                className="w-full flex items-center justify-center gap-2 text-[10px] font-bold text-gray-500 hover:text-cyan-400 transition-all uppercase tracking-widest py-2"
              >
                <Code className="w-3 h-3" /> {showCode ? 'Return to Core' : 'Python Inference Logic'}
              </button>
          </div>
        </aside>

        {/* Right Content Area */}
        <div className="lg:col-span-9 p-10 flex flex-col gap-10 overflow-y-auto bg-[#0B0F19] relative">
          
          <div className="flex justify-between items-end">
            <div>
              <div className="flex items-center gap-2 mb-2">
                 <span className="bg-cyan-500 text-black text-[9px] font-black px-2 py-0.5 rounded uppercase leading-none">Unlimited</span>
                 <span className="bg-gray-800 text-gray-400 text-[9px] font-bold px-2 py-0.5 rounded uppercase leading-none border border-gray-700">Enterprise</span>
              </div>
              <h2 className="text-4xl font-black tracking-tighter mb-2 italic uppercase">Neural Matrix Accelerator</h2>
              <p className="text-gray-500 text-sm font-medium">Parallel batch processing optimized for massive data ingestion.</p>
            </div>
            <div className="flex gap-3">
              <div className="px-6 py-3 bg-gray-900/60 border border-gray-800 rounded-2xl flex items-center gap-4 shadow-inner">
                <div className="flex -space-x-3">
                   {previews.map((p, i) => (
                     <motion.img 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        key={i} src={p} 
                        className="w-8 h-8 rounded-full border-2 border-gray-900 object-cover shadow-2xl" 
                      />
                   ))}
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-white uppercase leading-none">{files.length}</span>
                  <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mt-1">Files Buffered</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <MetricCard label="Virtual RAM" value={memoryUsage} progress={memoryUsage} icon={Cpu} />
            <MetricCard label="Core Latency" value="3.0s / unit" subtext="Static Speed Constraint" icon={Activity} />
            <MetricCard label="Cluster Load" value={`${files.length} Tasks`} subtext="Distributed Upscaling" icon={Box} />
            <MetricCard label="Uptime" value="100.0%" subtext="Network Resilience" icon={Zap} />
          </div>

          <div className="flex-1 min-h-[450px] flex flex-col gap-8">
            
            <AnimatePresence mode="wait">
              {showCode ? (
                <motion.div 
                  key="code"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="flex-1 bg-[#090C14] border border-gray-800 p-10 rounded-[40px] relative overflow-hidden group shadow-2xl"
                >
                  <pre className="font-mono text-[11px] text-emerald-400/70 leading-relaxed overflow-x-auto">
                    {ESRGAN_PYTHON_CODE}
                  </pre>
                  <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-transparent to-[#090C14]" />
                </motion.div>
              ) : (
                <motion.div 
                   key="matrix"
                   initial={{ opacity: 0 }}
                   animate={{ opacity: 1 }}
                   exit={{ opacity: 0 }}
                   className="flex-1 flex flex-col gap-8"
                >
                  <div className={cn(
                    "flex-1 border-2 border-dashed border-gray-800/60 rounded-[48px] bg-gray-900/20 relative overflow-hidden group cursor-pointer hover:border-cyan-500/40 transition-all flex flex-col items-center justify-center p-12 text-center shadow-inner",
                    files.length > 0 && "border-cyan-600/30 bg-cyan-600/5 shadow-[inset_0_0_50px_rgba(34,211,238,0.03)]"
                  )}>
                    <input type="file" multiple className="absolute inset-0 opacity-0 cursor-pointer z-10" onChange={handleFilesChange} accept="image/*" />
                    
                    {files.length === 0 ? (
                      <div className="flex flex-col items-center">
                        <div className="w-24 h-24 bg-gray-800 rounded-[32px] flex items-center justify-center mb-8 group-hover:scale-105 transition-all duration-500 shadow-[0_0_40px_rgba(0,0,0,0.5)]">
                          <Upload className="w-10 h-10 text-cyan-400 group-hover:animate-bounce" />
                        </div>
                        <h2 className="text-2xl font-black mb-2 uppercase tracking-tight">Ingest Neural Batch</h2>
                        <p className="text-gray-500 text-sm max-w-sm mx-auto leading-relaxed font-medium">
                          Deploy files into the accelerator. Each image will be forced to <span className="text-white font-black underline decoration-cyan-500">10MB - 45MB</span>.
                        </p>
                        <div className="mt-6 flex gap-3 text-cyan-500/80">
                           <span className="px-3 py-1 bg-cyan-950/20 border border-cyan-500/20 rounded-full text-[9px] font-bold uppercase tracking-widest flex items-center gap-2">
                             <Zap className="w-3 h-3 fill-cyan-500" /> Unlimited Neural Scaling Active
                           </span>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 w-full h-full p-6 overflow-y-auto custom-scrollbar">
                        {files.slice(0, 48).map((f, i) => (
                           <motion.div 
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: i * 0.02 }}
                              key={i} 
                              className="aspect-[4/5] bg-gray-900/80 rounded-3xl overflow-hidden border border-gray-800 relative group"
                           >
                              {i < previews.length ? (
                                <img src={previews[i]} className="w-full h-full object-cover opacity-40 group-hover:opacity-80 transition-opacity duration-700" />
                              ) : (
                                <div className="w-full h-full flex items-center justify-center bg-gray-950">
                                   <Box className="w-6 h-6 text-gray-800" />
                                </div>
                              )}
                              
                              {/* Single Upscale Hover Overlay */}
                              <div className="absolute inset-x-0 bottom-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform bg-gradient-to-t from-black via-black/80 to-transparent">
                                 <button 
                                    onClick={(e) => { e.stopPropagation(); handleSingleUpscale(i); }}
                                    className="w-full py-1.5 bg-cyan-500 hover:bg-cyan-400 text-black text-[9px] font-black rounded-lg uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                                 >
                                    <Zap className="w-3 h-3" /> Upscale Single
                                 </button>
                              </div>

                              <div className="absolute top-3 right-3 w-5 h-5 bg-black/60 backdrop-blur-md rounded-full flex items-center justify-center border border-white/5">
                                 <Layers className="w-2 h-2 text-cyan-400" />
                              </div>
                           </motion.div>
                        ))}
                        {files.length > 48 && (
                           <div className="aspect-[4/5] border-2 border-dashed border-gray-800 rounded-3xl flex flex-col items-center justify-center text-gray-600 gap-2 hover:bg-white/5 transition-colors group">
                              <span className="text-xl font-black text-gray-500">+{files.length - 48}</span>
                              <span className="text-[8px] font-bold uppercase tracking-widest">In Matrix Buffer</span>
                           </div>
                        )}
                      </div>
                    )}
                  </div>
                  <Terminal logs={logs} />
                </motion.div>
              )}
            </AnimatePresence>

          </div>

          <footer className="pt-8 flex justify-between items-center text-[9px] font-black text-gray-600 border-t border-gray-800 uppercase tracking-[0.25em]">
             <div className="flex gap-8">
                <span className="flex items-center gap-2 group cursor-help"><div className="w-1.5 h-1.5 rounded-full bg-cyan-700 group-hover:bg-cyan-400" /> Unified Processing</span>
                <span className="flex items-center gap-2 group cursor-help"><div className="w-1.5 h-1.5 rounded-full bg-cyan-700 group-hover:bg-cyan-400" /> Output Force: 10MB - 45MB</span>
                <a href="https://linktr.ee/sadik_official" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 group hover:text-cyan-400 transition-colors">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-700 group-hover:bg-cyan-400" /> Contact Developer
                </a>
             </div>
             <div className="flex items-center gap-3 text-gray-700">
                <AlertTriangle className="w-4 h-4 text-cyan-900 animate-pulse" />
                <span className="tracking-widest">accessForbidden_SYSTEM_STABLE_UNLIMITED</span>
             </div>
          </footer>
        </div>
      </main>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #1F2937; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #22D3EE; }
      `}} />
    </div>
  );
}
