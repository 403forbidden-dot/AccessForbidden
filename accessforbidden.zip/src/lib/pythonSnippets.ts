export const ESRGAN_PYTHON_CODE = `
import torch
from RealESRGAN import RealESRGAN
from PIL import Image
import os

def upscale_image(input_path, output_path, scale=4):
    """
    High-performance upscaling using Real-ESRGAN
    Optimized for memory efficiency
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = RealESRGAN(device, scale=scale)
    model.load_weights('weights/RealESRGAN_x4.pth', download=True)

    # Load image and process in chunks if necessary (for very large images)
    image = Image.open(input_path).convert('RGB')
    
    # Real-ESRGAN handles the heavy lifting
    sr_image = model.predict(image)
    
    sr_image.save(output_path)
    print(f"Upscaled image saved to {output_path}")

# Example Usage
if __name__ == "__main__":
    upscale_image('large_input.jpg', 'upscaled_output.png', scale=4)
`;

export const OPENCV_SR_CODE = `
import cv2
from cv2 import dnn_superres

def opencv_upscale(input_path, output_path, model_path='EDSR_x4.pb'):
    # Create SR object
    sr = dnn_superres.DnnSuperResImpl_create()

    # Read model
    sr.readModel(model_path)

    # Set model and scale
    sr.setModel("edsr", 4)

    # Read image
    image = cv2.imread(input_path)

    # Upscale
    result = sr.upscale(image)

    # Save
    cv2.imwrite(output_path, result)
`;
